package Day12_Defining_Classes_Exercises.P04;


public class Tyre {
    private double tirePressure;

    public Tyre(double tirePressure) {
        this.tirePressure = tirePressure;
    }

    public double getTirePressure() {
        return this.tirePressure;
    }
}